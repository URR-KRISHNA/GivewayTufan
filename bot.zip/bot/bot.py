import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import json, os, time

# ================= CONFIG =================
BOT_TOKEN = "8132926574:AAGWq5xh21b1torpdN3UT6ViD-XAM2r6ifI"
ADMIN_ID = 7878409802

CHANNELS = {
    "@Tufan_Loot": "https://t.me/Tufan_Loot",
    "@TufanStocks_Women": "https://t.me/TufanStocks_Women",
    "@TufanLoots": "https://t.me/TufanLoots"
}

CODE_FILE = "codes.txt"
USED_FILE = "used.json"
# ========================================

bot = telebot.TeleBot(BOT_TOKEN, parse_mode="Markdown")

# ---------- FILE INIT ----------
if not os.path.exists(USED_FILE):
    with open(USED_FILE, "w") as f:
        json.dump({}, f)

if not os.path.exists(CODE_FILE):
    open(CODE_FILE, "a").close()

def load_used():
    with open(USED_FILE) as f:
        return json.load(f)

def save_used(d):
    with open(USED_FILE, "w") as f:
        json.dump(d, f, indent=2)

def load_codes():
    with open(CODE_FILE) as f:
        return [c for c in f.read().splitlines() if c.strip()]

def save_codes(c):
    with open(CODE_FILE, "w") as f:
        f.write("\n".join(c))

# ---------- JOIN CHECK ----------
def is_joined(uid, chat):
    try:
        status = bot.get_chat_member(chat, uid).status
        return status in ("member", "administrator", "creator")
    except:
        return False

def joined_all(uid):
    for ch in CHANNELS:
        if not is_joined(uid, ch):
            return False
    return True

# ---------- UI ----------
def join_keyboard(uid):
    kb = InlineKeyboardMarkup()
    for ch, link in CHANNELS.items():
        if not is_joined(uid, ch):
            kb.add(InlineKeyboardButton("🔗 Join Channel", url=link))
    kb.add(InlineKeyboardButton("✅ I Joined – Continue", callback_data="check_join"))
    return kb

def main_menu():
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("🎁 Get Code", callback_data="get_code"))
    kb.add(InlineKeyboardButton("📦 My Redeemed Code", callback_data="my_code"))
    kb.add(InlineKeyboardButton("📊 Total Stocks", callback_data="stocks"))
    return kb

# ---------- START ----------
@bot.message_handler(commands=["start"])
def start(msg):
    uid = msg.from_user.id

    if not joined_all(uid):
        bot.send_message(
            msg.chat.id,
            "🚫 *Join all required channels to continue*",
            reply_markup=join_keyboard(uid)
        )
        return

    bot.send_message(
        msg.chat.id,
        "✅ *Welcome!*\nChoose an option below 👇",
        reply_markup=main_menu()
    )

# ---------- CALLBACKS ----------
@bot.callback_query_handler(func=lambda c: True)
def callbacks(call):
    uid = str(call.from_user.id)
    used = load_used()

    if call.data == "check_join":
        if joined_all(call.from_user.id):
            try:
                bot.delete_message(call.message.chat.id, call.message.message_id)
            except:
                pass
            start(call.message)
        else:
            bot.answer_callback_query(call.id, "❌ Please join all channels", show_alert=True)

    elif call.data == "get_code":
        if uid in used:
            bot.answer_callback_query(call.id, "❌ You already redeemed a code", show_alert=True)
            return

        codes = load_codes()
        if not codes:
            bot.answer_callback_query(call.id, "⚠️ No codes left", show_alert=True)
            return

        code = codes.pop(0)
        save_codes(codes)

        used[uid] = {"code": code, "time": int(time.time())}
        save_used(used)

        bot.send_message(call.message.chat.id, f"🎉 *Your Code:*\n`{code}`")

    elif call.data == "my_code":
        if uid not in used:
            bot.answer_callback_query(call.id, "❌ No code redeemed yet", show_alert=True)
            return
        bot.send_message(
            call.message.chat.id,
            f"📦 *Your Redeemed Code:*\n`{used[uid]['code']}`"
        )

    elif call.data == "stocks":
        bot.answer_callback_query(
            call.id,
            f"📊 Remaining Codes: {len(load_codes())}",
            show_alert=True
        )

# ---------- ADMIN ----------
@bot.message_handler(commands=["addcode"])
def add_code(msg):
    if msg.from_user.id != ADMIN_ID:
        return

    parts = msg.text.split("\n", 1)
    if len(parts) < 2:
        bot.send_message(msg.chat.id, "/addcode\nCODE1\nCODE2\nCODE3")
        return

    codes = load_codes()
    new = [c for c in parts[1].splitlines() if c.strip()]
    codes.extend(new)
    save_codes(codes)

    bot.send_message(msg.chat.id, f"✅ Added {len(new)} codes")

@bot.message_handler(commands=["stats"])
def stats(msg):
    if msg.from_user.id != ADMIN_ID:
        return

    bot.send_message(
        msg.chat.id,
        f"📊 *Bot Stats*\n\n"
        f"👥 Users Redeemed: {len(load_used())}\n"
        f"📦 Codes Left: {len(load_codes())}"
    )

@bot.message_handler(commands=["broadcast"])
def broadcast(msg):
    if msg.from_user.id != ADMIN_ID:
        return

    parts = msg.text.split(" ", 1)
    if len(parts) < 2:
        return

    sent = 0
    for uid in load_used():
        try:
            bot.send_message(uid, parts[1])
            sent += 1
        except:
            pass

    bot.send_message(msg.chat.id, f"✅ Broadcast sent to {sent} users")

# ---------- RUN ----------
print("🤖 Bot is running...")
bot.infinity_polling(skip_pending=True, none_stop=True, timeout=20)